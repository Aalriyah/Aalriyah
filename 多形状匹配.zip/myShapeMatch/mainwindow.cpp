#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget* parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    //initUi(true);
    ui->radioButton_btm->setChecked(true);
    on_radioButton_btm_clicked();
}

MainWindow::~MainWindow()
{
    delete ui;
}

//初始化
void MainWindow::initUi(bool topBtm)
{
    //清空默认图片路径
    ui->lineEdit_tmp->clear();
    ui->lineEdit_src->clear();
    //初始化各数值框
    ui->spinBox_delete->setValue(0);
    ui->spinBox_count->setValue(1);
    ui->ds_score->setValue(0.2);
    ui->ds_step->setValue(0.1);

    //默认选择上/下mark
    if(topBtm)
    {
        ui->radioButton_top->setChecked(true);
        on_radioButton_top_clicked();
    }
    else
    {
        ui->radioButton_btm->setChecked(true);
        on_radioButton_btm_clicked();
    }

    //是否显示图片
    ui->checkBox_showImg->setChecked(false);
}

//vector排序方式
static inline bool ContoursSortFun(vector<cv::Point> contour1, vector<cv::Point> contour2)
{
    return (cv::contourArea(contour1) > cv::contourArea(contour2));
}

//自定义数据结构,用于存储匹配节点
struct _myShape
{
    int _number;
    double _score;
    double _x;
    double _y;
};

//树状结构
struct _myTree
{
    _myShape myshape;
    vector<_myTree*> children;
};

//按位置删除vector
void deleteVector(vector<vector<Point>>& list, int i)
{
    for(vector<vector<Point>>::iterator it = list.begin(); it != list.end(); it++)
    {
        if(*it == list[i])
        {
            list.erase(it);
            return;
        }
    }
}

//将节点改为树状结构,便于理解和使用
vector<_myTree*> findMatchTree(vector<double> tmpX, vector<double> tmpY, vector<vector<_myShape>> mc, double x0, double y0, int number, double XYLimit = 1.0)
{
    vector<_myTree*> rst;
    if(number >= tmpX.size())
    {
        return rst;
    }
    double tx = tmpX[number];
    double ty = tmpY[number];
    //进行位置匹配
    for(int i = 0; i < mc[number].size(); i++)
    {
        int n = mc[number][i]._number;
        double x = mc[number][i]._x;
        double y = mc[number][i]._y;
        _myTree* mt = nullptr;
        double dx = abs(x - x0 - tx);
        double dy = abs(y - y0 - ty);
        if(dx < XYLimit && dy < XYLimit)
        {
            //在匹配树中记录
            if(mt == nullptr)
            {
                mt = new _myTree;
            }
            mt->myshape = mc[number][i];
            mt->myshape._score += (dx / XYLimit + dy / XYLimit);
            mt->children = findMatchTree(tmpX, tmpY, mc, x0, y0, number + 1, XYLimit);
        }
        if(mt != nullptr)
        {
            rst.push_back(mt);
            mt = nullptr;
        }
    }
    return rst;
}

//计算总轮廓的得分和位置
bool calContours(vector<_myTree*> matchTrees, vector<Point2f>& contoursCenter, vector<double>& score, int scoreSize, double scoreSum, double xSum, double ySum, int depth = 0)
{
    if(matchTrees.size() == 0)
    {
        return false;
    }
    scoreSize++;
    for(int i = 0; i < matchTrees.size(); i++)
    {
        double scoreSumTN = scoreSum + matchTrees[i]->myshape._score;
        double xSumTN = xSum + matchTrees[i]->myshape._x;
        double ySumTN = ySum + matchTrees[i]->myshape._y;
        if(!calContours(matchTrees[i]->children, contoursCenter, score, scoreSize, scoreSumTN, xSumTN, ySumTN, depth))
        {
            matchTrees[i]->myshape._score = scoreSumTN / scoreSize;
            matchTrees[i]->myshape._x = xSumTN / scoreSize;
            matchTrees[i]->myshape._y = ySumTN / scoreSize;
            if(scoreSize >= depth - 1 && depth > 0)
            {
                contoursCenter.push_back(Point2f(matchTrees[i]->myshape._x, matchTrees[i]->myshape._y));
                score.push_back(matchTrees[i]->myshape._score);
            }
        }
    }
    return true;
}

/// 多轮廓匹配(待优化,目前示例图运行速度50-150ms)
/// 说明:目前仅能匹配极其相似且左右/上下均对称的轮廓集合,且轮廓数量必须相同
/// 参数说明:
/// contoursTmp--模板轮廓集合
/// contoursSrc--目标轮廓集合
/// contoursCenter--匹配轮廓坐标中心集合(返回值,可能存在多个结果)
/// score--匹配轮廓得分(返回值,数量与contoursCenter相同,可用于二次筛选)
/// scoreLimit--子轮廓匹配得分限制(高于此分数的轮廓将被舍弃)
/// XYLimit--子轮廓相对位置匹配限制,单位:像素(超过此距离的轮廓将被舍弃)
bool MainWindow::matchMultipleShapes(vector<vector<Point>> contoursTmp, vector<vector<Point>> contoursSrc, vector<Point2f>& contoursCenter, vector<double>& score, double scoreLimit, double XYLimit)
{
    int tmpNum = contoursTmp.size();
    int srcNum = contoursSrc.size();
    if(tmpNum * srcNum == 0)
    {
        cout << "contours empty" << endl;
        return false;
    }
    //记录第一个子轮廓的位置
    double tmpx0 = moments(contoursTmp[0]).m10 / moments(contoursTmp[0]).m00;
    double tmpy0 = moments(contoursTmp[0]).m01 / moments(contoursTmp[0]).m00;
    Point2f pt0 = Point(tmpx0, tmpy0);
    //开始匹配模板子轮廓,以每一个子轮廓分组,记录序号/得分/位置/子轮廓位置
    vector<vector<_myShape>> matchContours;
    vector<double> tmpX;
    vector<double> tmpY;
    for(int i = 0; i < tmpNum; i++)
    {
        double areaTmp = contourArea(contoursTmp[i]);
        //当前子轮廓位置(相对第一个子轮廓)
        tmpX.push_back(moments(contoursTmp[i]).m10 / moments(contoursTmp[i]).m00 - tmpx0);
        tmpY.push_back(moments(contoursTmp[i]).m01 / moments(contoursTmp[i]).m00 - tmpy0);
        //找到与当前子轮廓匹配的轮廓
        vector<_myShape> shapes;
        for(int j = 0; j < srcNum; j++)
        {
            double sc = matchShapes(contoursTmp[i], contoursSrc[j], CONTOURS_MATCH_I1, 0);
            //得分筛选
            if(sc < scoreLimit)
            {
                double areaSrc = contourArea(contoursSrc[j]);
                if(areaSrc / areaTmp < 0.8 || areaSrc / areaTmp > 1.25)
                    continue;
                double x = moments(contoursSrc[j]).m10 / moments(contoursSrc[j]).m00;
                double y = moments(contoursSrc[j]).m01 / moments(contoursSrc[j]).m00;
                _myShape ms = {j, sc, x, y};
                shapes.push_back(ms);
            }
        }
        matchContours.push_back(shapes);
    }
    //位置筛选并将筛选结果(序号)转换为树状结构
    vector<_myTree*> matchTrees;
    for(int i = 0; i < matchContours[0].size(); i++)
    {
        _myTree* mt = new _myTree;
        mt->myshape = matchContours[0][i];
        double X0 = matchContours[0][i]._x;
        double Y0 = matchContours[0][i]._y;
        //按子轮廓数量进行(从第二个图形开始)
        mt->children = findMatchTree(tmpX, tmpY, matchContours, X0, Y0, 1, XYLimit);
        matchTrees.push_back(mt);
    }
    //重新计算树状结构的分数(此处判断空队列)
    if(!calContours(matchTrees, contoursCenter, score, 0, 0, 0, 0, tmpX.size()))
    {
        cout << "find none" << endl;
        return false;
    }
    return true;
}

void MainWindow::on_pushButton_go_clicked()
{
    if(ui->lineEdit_tmp->text() != "" && ui->lineEdit_src->text() != "")
    {
        //变量声明及赋值
        int tmpLoc = 0;
        Mat tmp = imread(ui->lineEdit_tmp->text().toStdString(), IMREAD_GRAYSCALE);
        Mat src = imread(ui->lineEdit_src->text().toStdString(), IMREAD_GRAYSCALE);
        if(tmp.empty() || src.empty())
        {
            cout << "[Error] Empty Image" << endl;
            return;
        }
        Mat tmpB = tmp.clone();
        Mat srcB = src.clone();
        Mat elementTop = getStructuringElement(MORPH_RECT, Size(11, 11));
        Mat elementBtm = getStructuringElement(MORPH_RECT, Size(33, 33));
        bool showImg = ui->checkBox_showImg->isChecked();
        bool topBtm = true;
        if(ui->radioButton_top->isChecked())
        {
            topBtm = true;
        }
        else if(ui->radioButton_btm->isChecked())
        {
            topBtm = false;
        }

        //模板轮廓提取(此部分内容可以提前处理,无需占用识别时间)
        if(topBtm)
        {
            blur(tmp, tmpB, Size(11, 11));
            adaptiveThreshold(tmpB, tmpB, 255, ADAPTIVE_THRESH_MEAN_C, THRESH_BINARY_INV, 11, 0);
        }
        else
        {
            blur(tmp, tmpB, Size(11, 11));
            adaptiveThreshold(tmpB, tmpB, 255, ADAPTIVE_THRESH_MEAN_C, THRESH_BINARY_INV, 99, 0);
        }
        if(showImg)
        {
            namedWindow("tmpB", WINDOW_NORMAL);
            imshow("tmpB", tmpB);
        }
        vector<vector<Point>> contoursTmp;
        vector<cv::Vec4i> hierarchyTmp;
        findContours(tmpB, contoursTmp, hierarchyTmp, RETR_EXTERNAL, CHAIN_APPROX_NONE);
        drawContours(tmpB, contoursTmp, -1, Scalar(255), -1);
        findContours(tmpB, contoursTmp, hierarchyTmp, RETR_EXTERNAL, CHAIN_APPROX_NONE);
        sort(contoursTmp.begin(), contoursTmp.end(), ContoursSortFun);
        //对Btm删除一些干扰因素,以便获取到精确模板
        if(!topBtm)
        {
            for(int i = 0; i < ui->spinBox_delete->value(); i++)
            {
                deleteVector(contoursTmp, 0);
            }
            for(int i = ui->spinBox_count->value(); i < contoursTmp.size(); i++)
            {
                contoursTmp.pop_back();
            }
        }
        if(showImg)
        {
            namedWindow("tmpB", WINDOW_NORMAL);
            imshow("tmpB", tmpB);
        }

        //测试图预处理
        timeStart = QDateTime::currentDateTime();
        if(topBtm)
        {
            blur(src, srcB, Size(11, 11));
            adaptiveThreshold(srcB, srcB, 255, ADAPTIVE_THRESH_MEAN_C, THRESH_BINARY_INV, 51, 0);
            morphologyEx(srcB, srcB, MORPH_OPEN, elementTop);
        }
        else
        {
            blur(src, srcB, Size(11, 11));
            adaptiveThreshold(srcB, srcB, 255, ADAPTIVE_THRESH_MEAN_C, THRESH_BINARY_INV, 99, 0);
            morphologyEx(srcB, srcB, MORPH_OPEN, elementBtm);
        }
        if(showImg)
        {
            namedWindow("srcB", WINDOW_NORMAL);
            imshow("srcB", srcB);
        }
        vector<vector<Point>> contoursSrc;
        vector<cv::Vec4i> hierarchySrc;
        findContours(srcB, contoursSrc, hierarchySrc, RETR_EXTERNAL, CHAIN_APPROX_NONE);
        sort(contoursSrc.begin(), contoursSrc.end(), ContoursSortFun);

        //轮廓筛选
        if(topBtm)
        {
            //top
            double areaTmp = contourArea(contoursTmp[tmpLoc]);
            int total = contoursSrc.size();
            int count = 0;
            double scoreLimit = 0;
            map<int, double> scores;
            map<int, Point2f> centers;
            while(count < 1)
            {
                if(scoreLimit >= ui->ds_score->value())
                {
                    cout << "Not Found!" << endl;
                    return;
                }
                scoreLimit += ui->ds_step->value();
                count = 0;
                scores.clear();
                double score = 99;
                for(int i = 0; i < contoursSrc.size(); i++)
                {
                    score = matchShapes(contoursTmp[tmpLoc], contoursSrc[i], CONTOURS_MATCH_I1, 0);
                    if(score < scoreLimit)
                    {
                        double areaSrc = contourArea(contoursSrc[i]);
                        if(areaSrc / areaTmp < 0.8 || areaSrc / areaTmp > 1.25)
                            continue;
                        RotatedRect rct = minAreaRect(contoursSrc[i]);
                        if(rct.size.width / rct.size.height < 0.8 || rct.size.width / rct.size.height > 1.25)
                            continue;
                        scores[i] = score;
                        centers[i] = rct.center;
                        count++;
                    }
                }
            }

            //结果输出
            cout << "Score Limit:" << scoreLimit << endl;
            cout << "Count:" << count << endl;
            for(map<int, double>::iterator it = scores.begin(); it != scores.end(); it++)
            {
                if(showImg)
                {
                    Mat mat = src.clone();
                    drawContours(mat, contoursSrc, it->first, Scalar(255), 5);
                    namedWindow("src" + to_string(it->first + 1) + ": " + to_string(it->second), WINDOW_NORMAL);
                    imshow("src" + to_string(it->first + 1) + ": " + to_string(it->second), mat);
                }
                cout << it->first + 1 << "/" << total << ": " << it->second << endl;
                cout << "Center:" << centers[it->first] << endl;
            }
        }
        else
        {
            //btm
            vector<Point2f> contoursCenter;
            vector<double> scores;
            if(matchMultipleShapes(contoursTmp, contoursSrc, contoursCenter, scores, ui->ds_score->value(), 10))
            {
                cout << "Score Limit:" << ui->ds_score->value() << endl;
                cout << "Count:" << contoursCenter.size() << endl;
                for(int i = 0; i < contoursCenter.size(); i++)
                {
                    if(showImg)
                    {
                        Mat mat = src.clone();
                        circle(mat, contoursCenter[i], 50, Scalar(0), 50);
                        namedWindow("src" + to_string(i + 1) + ": " + to_string(contoursCenter.size()), WINDOW_NORMAL);
                        imshow("src" + to_string(i + 1) + ": " + to_string(contoursCenter.size()), mat);
                    }
                    cout << i + 1 << "/" << contoursCenter.size() << ": " << scores[i] << endl;
                    cout << "Center:" << contoursCenter[i] << endl;
                }
            }
        }
        timeEnd = QDateTime::currentDateTime();
        int time = timeEnd.toMSecsSinceEpoch() - timeStart.toMSecsSinceEpoch();
        cout << "Total Time(ms):" << time << endl;
    }
}

void MainWindow::on_radioButton_top_clicked()
{
    ui->spinBox_count->setEnabled(false);
    ui->spinBox_delete->setEnabled(false);
    ui->ds_step->setEnabled(true);
}

void MainWindow::on_radioButton_btm_clicked()
{
    ui->spinBox_count->setEnabled(true);
    ui->spinBox_delete->setEnabled(true);
    ui->ds_step->setEnabled(false);
}
