#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <opencv.hpp>
#include <QDateTime>

using namespace cv;
using namespace std;

namespace Ui
{
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget* parent = nullptr);
    ~MainWindow();

private slots:
    void on_pushButton_go_clicked();

    void on_radioButton_top_clicked();

    void on_radioButton_btm_clicked();

private:
    void initUi(bool topBtm = true);
    bool matchMultipleShapes(vector<vector<Point>> contoursTmp, vector<vector<Point>> contoursSrc, vector<Point2f>& contoursCenter, vector<double>& score, double scoreLimit, double XYLimit = 1.0);
    Ui::MainWindow* ui;
    QDateTime timeStart;
    QDateTime timeEnd;
};

#endif // MAINWINDOW_H
