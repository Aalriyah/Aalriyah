/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.12.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QDoubleSpinBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout;
    QSpacerItem *horizontalSpacer_6;
    QLabel *label;
    QLineEdit *lineEdit_tmp;
    QSpacerItem *horizontalSpacer_3;
    QHBoxLayout *horizontalLayout_2;
    QSpacerItem *horizontalSpacer_5;
    QLabel *label_2;
    QLineEdit *lineEdit_src;
    QSpacerItem *horizontalSpacer_4;
    QHBoxLayout *horizontalLayout_6;
    QSpacerItem *horizontalSpacer_11;
    QRadioButton *radioButton_top;
    QRadioButton *radioButton_btm;
    QSpacerItem *horizontalSpacer_12;
    QHBoxLayout *horizontalLayout_3;
    QSpacerItem *horizontalSpacer_8;
    QLabel *label_6;
    QSpinBox *spinBox_delete;
    QLabel *label_5;
    QSpinBox *spinBox_count;
    QSpacerItem *horizontalSpacer_7;
    QHBoxLayout *horizontalLayout_4;
    QSpacerItem *horizontalSpacer_9;
    QLabel *label_3;
    QDoubleSpinBox *ds_score;
    QLabel *label_4;
    QDoubleSpinBox *ds_step;
    QSpacerItem *horizontalSpacer_10;
    QHBoxLayout *horizontalLayout_5;
    QSpacerItem *horizontalSpacer;
    QCheckBox *checkBox_showImg;
    QPushButton *pushButton_go;
    QSpacerItem *horizontalSpacer_2;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(422, 268);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        verticalLayout = new QVBoxLayout(centralWidget);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(6);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalSpacer_6 = new QSpacerItem(40, 20, QSizePolicy::Preferred, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_6);

        label = new QLabel(centralWidget);
        label->setObjectName(QString::fromUtf8("label"));

        horizontalLayout->addWidget(label);

        lineEdit_tmp = new QLineEdit(centralWidget);
        lineEdit_tmp->setObjectName(QString::fromUtf8("lineEdit_tmp"));

        horizontalLayout->addWidget(lineEdit_tmp);

        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Preferred, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_3);


        verticalLayout->addLayout(horizontalLayout);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalSpacer_5 = new QSpacerItem(40, 20, QSizePolicy::Preferred, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_5);

        label_2 = new QLabel(centralWidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        horizontalLayout_2->addWidget(label_2);

        lineEdit_src = new QLineEdit(centralWidget);
        lineEdit_src->setObjectName(QString::fromUtf8("lineEdit_src"));

        horizontalLayout_2->addWidget(lineEdit_src);

        horizontalSpacer_4 = new QSpacerItem(40, 20, QSizePolicy::Preferred, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_4);


        verticalLayout->addLayout(horizontalLayout_2);

        horizontalLayout_6 = new QHBoxLayout();
        horizontalLayout_6->setSpacing(6);
        horizontalLayout_6->setObjectName(QString::fromUtf8("horizontalLayout_6"));
        horizontalSpacer_11 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_6->addItem(horizontalSpacer_11);

        radioButton_top = new QRadioButton(centralWidget);
        radioButton_top->setObjectName(QString::fromUtf8("radioButton_top"));
        radioButton_top->setChecked(true);

        horizontalLayout_6->addWidget(radioButton_top);

        radioButton_btm = new QRadioButton(centralWidget);
        radioButton_btm->setObjectName(QString::fromUtf8("radioButton_btm"));
        radioButton_btm->setChecked(false);

        horizontalLayout_6->addWidget(radioButton_btm);

        horizontalSpacer_12 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_6->addItem(horizontalSpacer_12);


        verticalLayout->addLayout(horizontalLayout_6);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setSpacing(6);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        horizontalSpacer_8 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer_8);

        label_6 = new QLabel(centralWidget);
        label_6->setObjectName(QString::fromUtf8("label_6"));

        horizontalLayout_3->addWidget(label_6);

        spinBox_delete = new QSpinBox(centralWidget);
        spinBox_delete->setObjectName(QString::fromUtf8("spinBox_delete"));
        spinBox_delete->setMinimum(0);
        spinBox_delete->setValue(4);

        horizontalLayout_3->addWidget(spinBox_delete);

        label_5 = new QLabel(centralWidget);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        horizontalLayout_3->addWidget(label_5);

        spinBox_count = new QSpinBox(centralWidget);
        spinBox_count->setObjectName(QString::fromUtf8("spinBox_count"));
        spinBox_count->setMinimum(1);
        spinBox_count->setValue(28);

        horizontalLayout_3->addWidget(spinBox_count);

        horizontalSpacer_7 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer_7);


        verticalLayout->addLayout(horizontalLayout_3);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setSpacing(6);
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        horizontalSpacer_9 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_4->addItem(horizontalSpacer_9);

        label_3 = new QLabel(centralWidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        horizontalLayout_4->addWidget(label_3);

        ds_score = new QDoubleSpinBox(centralWidget);
        ds_score->setObjectName(QString::fromUtf8("ds_score"));
        QSizePolicy sizePolicy(QSizePolicy::Minimum, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(ds_score->sizePolicy().hasHeightForWidth());
        ds_score->setSizePolicy(sizePolicy);
        ds_score->setMinimum(0.010000000000000);
        ds_score->setSingleStep(0.100000000000000);
        ds_score->setValue(0.500000000000000);

        horizontalLayout_4->addWidget(ds_score);

        label_4 = new QLabel(centralWidget);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        horizontalLayout_4->addWidget(label_4);

        ds_step = new QDoubleSpinBox(centralWidget);
        ds_step->setObjectName(QString::fromUtf8("ds_step"));
        sizePolicy.setHeightForWidth(ds_step->sizePolicy().hasHeightForWidth());
        ds_step->setSizePolicy(sizePolicy);
        ds_step->setMinimum(0.010000000000000);
        ds_step->setMaximum(19.989999999999998);
        ds_step->setSingleStep(0.100000000000000);
        ds_step->setValue(0.100000000000000);

        horizontalLayout_4->addWidget(ds_step);

        horizontalSpacer_10 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_4->addItem(horizontalSpacer_10);


        verticalLayout->addLayout(horizontalLayout_4);

        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setSpacing(6);
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_5->addItem(horizontalSpacer);

        checkBox_showImg = new QCheckBox(centralWidget);
        checkBox_showImg->setObjectName(QString::fromUtf8("checkBox_showImg"));

        horizontalLayout_5->addWidget(checkBox_showImg);

        pushButton_go = new QPushButton(centralWidget);
        pushButton_go->setObjectName(QString::fromUtf8("pushButton_go"));

        horizontalLayout_5->addWidget(pushButton_go);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_5->addItem(horizontalSpacer_2);


        verticalLayout->addLayout(horizontalLayout_5);

        MainWindow->setCentralWidget(centralWidget);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", nullptr));
        label->setText(QApplication::translate("MainWindow", "\346\250\241\346\235\277\345\233\276:", nullptr));
        lineEdit_tmp->setText(QApplication::translate("MainWindow", "/home/ubuntu/image/test/2.bmp", nullptr));
        label_2->setText(QApplication::translate("MainWindow", "\346\265\213\350\257\225\345\233\276:", nullptr));
        lineEdit_src->setText(QApplication::translate("MainWindow", "/home/ubuntu/image/test/41.bmp", nullptr));
        radioButton_top->setText(QApplication::translate("MainWindow", "Single", nullptr));
        radioButton_btm->setText(QApplication::translate("MainWindow", "Multiple ", nullptr));
        label_6->setText(QApplication::translate("MainWindow", "\345\244\247\345\235\227\350\275\256\345\273\223\345\216\273\351\231\244:", nullptr));
        label_5->setText(QApplication::translate("MainWindow", "\350\275\256\345\273\223\346\225\260\351\207\217:", nullptr));
        label_3->setText(QApplication::translate("MainWindow", "\345\214\271\351\205\215\345\210\206\346\225\260:", nullptr));
        label_4->setText(QApplication::translate("MainWindow", "\345\215\225\346\255\245\345\210\206\346\225\260:", nullptr));
        checkBox_showImg->setText(QApplication::translate("MainWindow", "\346\230\276\347\244\272\345\233\276\347\211\207", nullptr));
        pushButton_go->setText(QApplication::translate("MainWindow", "Go", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
